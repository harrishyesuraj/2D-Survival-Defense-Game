using UnityEngine;

public class Enemy_Respon : MonoBehaviour
{


    [SerializeField] private GameObject EnemyPrefab;
    [SerializeField] private Transform[] RespawnPoints ;
    [Space] 


    private Transform player ;
    [SerializeField] private float TimerForRespawn ;

    [Space]

    [SerializeField] private float Cooldown = 4F;
    [SerializeField] private float CooldownDecreaseRate = 0.5f ;
    [SerializeField] private float CooldownCap = 1.2f ;



    private void Awake()
    {
        player = FindAnyObjectByType<Player>().transform ;
        TimerForRespawn = Cooldown ;
    }

    private void Update()
    {
        if (player == null)
            return;


        TimerForRespawn -= Time.deltaTime ;

        if(TimerForRespawn < 0)
        {
            TimerForRespawn = Cooldown ;
            CreateNewenemy();

            Cooldown = Mathf.Max( CooldownCap, Cooldown - CooldownDecreaseRate ) ;

        }
    }


    private void CreateNewenemy()
    {
        int RespawnPointIndex = Random.Range(0, RespawnPoints.Length);
        Vector3 SpawnPoint = RespawnPoints[RespawnPointIndex].position ;

        GameObject newEnemy = Instantiate(EnemyPrefab, SpawnPoint, Quaternion.identity ) ;

        bool createdOnTheRight = newEnemy.transform.position.x > player.transform.position.x ;

        if(createdOnTheRight)
        {
            newEnemy.GetComponent<Enemy>().flip() ;
        }
    }



}
