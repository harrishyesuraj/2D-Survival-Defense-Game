using UnityEngine;

public class Player : Entity
{


    private float X_axis ;


    [Header("Movement Details")] 
    [SerializeField] protected float Speed = 5.0f ;
    [SerializeField] protected float JumpForce = 10f ;
    [SerializeField] private bool isJump = true ;


    protected override void Update()
    {
        base.Update();

        Handle_Jump();
        Handle_Attack();
    }


    protected override void Handle_Move()
    {
        X_axis = Input.GetAxis("Horizontal") * Speed ;
        if(isMove)
            Rb.linearVelocity = new Vector2(X_axis, Rb.linearVelocity.y );
        else
            Rb.linearVelocity = new Vector2(0, Rb.linearVelocity.y );
    }
    protected override void Handle_Animation()
    {
        base.Handle_Animation();
        
        Anima.SetFloat("Yvelocity", Rb.linearVelocity.y) ;
        Anima.SetBool("IsGround",isGrounded) ;
    }


    private void Handle_Jump()
    {
        if (Input.GetKeyDown(KeyCode.Space))
            jump();
        else if(Input.GetKeyDown(KeyCode.UpArrow))
            jump();
        else if(Input.GetKeyDown(KeyCode.W))
            jump();
    }
    private void jump()
    {
        if(isGrounded && isJump)
            Rb.linearVelocity = new Vector2( Rb.linearVelocity.x, JumpForce ) ;
    }
    private void Handle_Attack()
    {
        if(Input.GetKeyDown(KeyCode.Mouse0))
            AttemptToAttack();
    }


    public override void EnableMovement(bool Enable)
    {
        base.EnableMovement(Enable);
        isJump = Enable ;
    }


    protected override void Die()
    {
        base.Die();

        UI.instance.EnableGameOver();
    }


}
