using System.Collections;
using UnityEngine;
using UnityEngine.UIElements;

public class Entity : MonoBehaviour
{


    protected Animator Anima ;
    protected Rigidbody2D Rb ;
    protected SpriteRenderer Sr ;
    private Collider2D coll ;


    [Header("Health Details")]
    [SerializeField] private int MaxHealth = 10 ;
    [SerializeField] private int CurrentHealth ;
    [SerializeField] private Material DamageMeterial ;
    [SerializeField] private float DamageFeedbackDuration = .1f ;
    private Coroutine DamageFeedbackCorotine ;


    [Header("Attack Detection")]
    [SerializeField] protected float AttackRadius ;
    [SerializeField] protected Transform Attackpoint ;
    [SerializeField] protected LayerMask WhatIsTarget ;


    [Header("Collision Details")]
    [SerializeField] protected float GroundCheckDistance ;
    [SerializeField] protected LayerMask WhatIsGround ;
    [SerializeField] protected bool isGrounded ;


// Facing Direction Details
    protected bool Facing_Right = true ;
    protected int FacingDirEnemy = 1 ;
    [SerializeField]protected bool isMove = true ;


// --------------------------------------------------------------------------------------------------//
// Additionals

    protected Transform healthBar;
    protected Vector3 OrigionalScale ;
    [SerializeField]private float X_scale ;
// --------------------------------------------------------------------------------------------------//


    protected virtual void Awake()
    {
        Rb = GetComponent<Rigidbody2D>();
        Anima = GetComponentInChildren<Animator>();
        Sr = GetComponentInChildren<SpriteRenderer>();
        coll = GetComponent<Collider2D>() ;

        CurrentHealth = MaxHealth ;

// --------------------------------------------------------------------------------------------------//
// Additionals
        healthBar = transform.Find("HealthBar");
        OrigionalScale = healthBar.localScale ;

// --------------------------------------------------------------------------------------------------//

    }


    // Update is called once per frame
    protected virtual void Update()
    {
        Handle_Collision();
        Handle_Move();
        Handle_Flip();
        Handle_Animation();
    }


// methods used in update();
    protected virtual void Handle_Collision()
    {
        isGrounded = Physics2D.Raycast(transform.position, Vector2.down, GroundCheckDistance, WhatIsGround ) ;
    }
    protected virtual void Handle_Move()
    {}
    protected virtual void Handle_Flip() 
    {
        if( Rb.linearVelocity.x > 0 && Facing_Right == false )
            flip() ;
        else if( Rb.linearVelocity.x < 0 && Facing_Right == true )
            flip() ;
    }
    public void flip() //enemy
    {
        transform.Rotate(0, 180, 0);
        Facing_Right = !Facing_Right ;
        FacingDirEnemy = FacingDirEnemy * -1 ;
    }
    protected virtual void Handle_Animation()
    {
        Anima.SetFloat("Xvelocity", Rb.linearVelocity.x) ;
    }


// method to attack and damage entity 
    public void DamageTarget()
    {
        Collider2D[] EntityColliders = Physics2D.OverlapCircleAll(Attackpoint.position, AttackRadius, WhatIsTarget);
        foreach (Collider2D entity in EntityColliders) // each enemy 2D-components
        {
           Entity EntityTarget = entity.GetComponent<Entity>() ;
           EntityTarget.TakeDamage() ;
        }
    }
    private void TakeDamage()
    {
        PlayDamageFeedback();
        HealthBarAtivateOnHit();
        if(CurrentHealth <= 0 )
            Die();
    }
    private void PlayDamageFeedback()
    {
        CurrentHealth -= 1 ;
        if(DamageFeedbackCorotine != null )
            StopCoroutine(DamageFeedbackCorotine) ;

        StartCoroutine(DamageFeedbackCo());
    }
    protected virtual void Die()
    {
        Anima.enabled = false ;
        coll.enabled = false ;

        Rb.gravityScale = 12 ;
        Rb.linearVelocity = new Vector2(Rb.linearVelocity.x, 15 );

        Destroy(gameObject, 3) ;
    }
    private IEnumerator DamageFeedbackCo()
    {
        Material origional_material = Sr.material ;
        Sr.material = DamageMeterial ;
        yield return new WaitForSeconds(DamageFeedbackDuration);
        Sr.material = origional_material ;
    }


// method to controll the attack on air and movement
    public virtual void EnableMovement(bool Enable)
    {
        isMove = Enable ;
    }
    

 // methods used to trriger animation on animator
    protected void AttemptToAttack()  
    {
        if(isGrounded)
            Anima.SetTrigger("attack");
    }


// method for Gizmos
    private void OnDrawGizmos()
    {
        Gizmos.DrawLine(transform.position, transform.position + new Vector3(0,-GroundCheckDistance)) ;
        if(Attackpoint != null)
            Gizmos.DrawWireSphere(Attackpoint.position, AttackRadius);
    }
    

// --------------------------------------------------------------------------------------------------//
// Additionals
        private IEnumerator ScaleTemporarily()
    {
        X_scale = (float)CurrentHealth / MaxHealth ;
        healthBar.localScale = OrigionalScale + new Vector3(X_scale, 0, 0);

        yield return new WaitForSeconds(1.5f);

        healthBar.localScale = OrigionalScale ;
    }

    public void HealthBarAtivateOnHit()
    {
        StartCoroutine(ScaleTemporarily());
    }


// --------------------------------------------------------------------------------------------------//


}