using UnityEngine;

public class ObjectToProtect : Entity
{


    [Header("Extra Detaails")]
    [SerializeField]private Transform player ;


    protected override void Awake()
    {
        base.Awake();

        player = FindFirstObjectByType<Player>().transform ;

    }


    protected override void Update()
    {
        Handle_Flip();
    }


    protected override void Handle_Flip()
    {
        if(player == null)
            return;

        if( player.transform.position.x > transform.position.x && Facing_Right == false )
            flip() ;
        else if( player.transform.position.x < transform.position.x && Facing_Right == true )
            flip() ;
    }


    protected override void Die()
    {
        base.Die();

        UI.instance.EnableGameOver();
    }

}