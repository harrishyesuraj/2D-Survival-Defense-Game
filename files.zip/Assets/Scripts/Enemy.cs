using UnityEngine;
public class Enemy : Entity
{


    [SerializeField] private bool PlayerDetected ; 
    


    [Header("Movement Details")] 
    [SerializeField] protected float Speed = 5.0f ;
    

    protected override void Update()
    {
        base.Update();

        Handle_Attack();
    }



    protected override void Handle_Collision()
    {
        PlayerDetected = Physics2D.OverlapCircle(Attackpoint.position, AttackRadius, WhatIsTarget) ;
        isGrounded = true ;
    }
    protected override void Handle_Move()
    {
        if(isMove)
            Rb.linearVelocity = new Vector2(FacingDirEnemy, Rb.linearVelocity.y );
        else
            Rb.linearVelocity = new Vector2(0, Rb.linearVelocity.y );
    }


    private void Handle_Attack()
    {
        if(PlayerDetected)
            AttemptToAttack();
    }


    protected override void Die()
    {
        base.Die();
        UI.instance.AddKillCount() ;
    }


}