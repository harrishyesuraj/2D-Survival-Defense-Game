using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;

public class UI : MonoBehaviour
{


    public static UI instance ;


    [SerializeField] private GameObject PreGameUI ;
    [SerializeField] private GameObject InGameUI ;
    [SerializeField] private GameObject GameOverUI ;


    [Space]


    private bool isGameRunning = false ;
    private int KillCount ;
    private float TimeCount ;


    [SerializeField] private TextMeshProUGUI TimerText ;
    [SerializeField] private TextMeshProUGUI KillText ;
    public static bool RestartFromRetry = false;


    public void Awake()
    {
        instance = this ;
        Time.timeScale = 0f;

        if(RestartFromRetry)
        {
            RestartFromRetry = false ;
            StartGame();
        }
        else
        {
            PreGameUI.SetActive(true);
            InGameUI.SetActive(false);
            GameOverUI.SetActive(false);
        }
    }


    private void Update()
    {
        if (!isGameRunning)
            return;

        AddTimeCount();
    }


// Buttons methods
    public void StartGame() // Start button
    {
        
        Time.timeScale = 1 ;
        isGameRunning = true ;

        PreGameUI.SetActive(false);
        InGameUI.SetActive(true);
        GameOverUI.SetActive(false);

        ResetParameter();
    }
    public void RestartLevel() // Retry button
    {
        Time.timeScale = 1 ;
        isGameRunning = true;
        RestartFromRetry = false;

        int screenIndex = SceneManager.GetActiveScene().buildIndex;
        SceneManager.LoadScene(screenIndex); 

    }
    public void QuitGame() // Quit button
    {
    #if(UnityEditor) // IF testing in Unity Editor
        {
            Debug.Log("Quit Game (Editor)");
            UnityEditor.EditorApplication.isPlaying = false; // Stop play mode
        }
    #else  // ELSE
        {    
            Application.Quit(); // Quit the actual game
        }
    #endif
    }

// Parameter methods
    private void ResetParameter() // Time,Kill Reset
    {
        TimeCount = 0 ;
        KillCount = 0 ;

        TimerText.text = "0s" ;
        KillText.text = "0" ;
    }
    public void AddKillCount() // kill count string 
    {
        if(isGameRunning)
        {
            KillCount++ ;
            KillText.text = KillCount.ToString() ;    
        }
    }
    public void AddTimeCount() // time count string
    {
        if(isGameRunning)
        {
            TimeCount += Time.deltaTime ;
            TimerText.text = TimeCount.ToString("F2") + "s" ;
        }
    }


    public void EnableGameOver() // GameOver Screen
    {
        Time.timeScale = 0.5f ;
        isGameRunning = false ;

        PreGameUI.SetActive(false);
        InGameUI.SetActive(true);
        GameOverUI.SetActive(true);
    }


}