using UnityEngine;

public class EntityAnimationEvents : MonoBehaviour
{


    private Entity entity ;


    private void Awake()
    {
        entity = GetComponentInParent<Entity>() ;
    } 


    public void DamageTarget() => entity.DamageTarget() ;


    public void EnableJumpAndMove() => entity.EnableMovement(true);
    public void DisableJumpAndMove() => entity.EnableMovement(false);


}